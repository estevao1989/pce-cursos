import './App.css'
import React from 'react'
import NavBar from './components/NavBar'
import { BrowserRouter as Router } from 'react-router-dom'
import MainRoutes from './components/MainRoutes'

const App = props => {

  return (
    <div className="app">
      <Router>
        <NavBar />
        <MainRoutes />
      </Router>
    </div>
  )
}

export default App;
