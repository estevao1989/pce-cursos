import React, { useContext, useEffect, useState } from "react";
import './Playlist.css'
import Main from "../components/Main";
import { useParams } from "react-router";
import youtube from "./youtube";
import { VideoContext } from '../data/DataContext'
import Lista from "./Lista";




export default props => {

    const { setEstado, estado } = useContext(VideoContext)

    const { id } = useParams()
    const [lista, setLista] = useState([])
    const [videoSelected, setVideoSelected] = useState()


    useEffect(() => {
        setEstado(!estado)
    }, [lista])

    useEffect(() => {
        youtube.get('playlistItems', {
            params: {
                playlistId: id,
                maxResults: 80
            }
        }).then(response => {
            setLista(response.data.items)
            if (response.data.items[0].title !== "Private Video") {
                setVideoSelected(response.data.items[0])
            } else {
                setVideoSelected(response.data.items[1])
            }
        })
    }, [])
    if (videoSelected !== undefined) {
        return (
            <Main>
                <div className="playlist">
   
                        <div className="video-selecionado">
                            <iframe
                                src={`https://www.youtube.com/embed/${videoSelected.snippet.resourceId.videoId}`} frameborder="0"
                                width={videoSelected.snippet.thumbnails.standard.width}
                                height={videoSelected.snippet.thumbnails.standard.height}
                            ></iframe>
                            <div className="gradient-gray" style={{ width: videoSelected.snippet.thumbnails.standard.width }}>
                                <h3>Sobre o curso</h3>
                                <h6>{videoSelected.snippet.title}</h6>
                                <h6>Fornecido por {videoSelected.snippet.channelTitle}</h6>
                            </div>
                        </div>
                        <div className="lista-de-videos overflow-auto">
                            <Lista
                                lista={lista}
                                func={setVideoSelected}
                            ></Lista>
                        </div>
                    </div>
                
            </Main>
        )
    } else {
        return (
            <div class="text-center">
                <div class="spinner-border" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        )
    }
}
