import React, {useContext } from 'react'
import { VideoContext } from '../data/DataContext'
import { useHistory } from 'react-router'
import Main from './Main'
import Course from '../courses/Course'

export default props => {

    const { playlistsTitle } = useContext(VideoContext)
  
    const cursos = playlistsTitle.map(curso => {
        return (
            <Course
                key={curso.id}
                playListId={curso.id}
                title={curso.snippet.title}
                image={curso.snippet.thumbnails.standard.url}
                vendor={curso.snippet.channelTitle}
            ></Course>
        )
    })
    return (
        <Main>
            {cursos}
        </Main>
    )
}
