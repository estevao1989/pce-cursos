import React from 'react'
import './NavBar.css'
import Logo from './Logo'
import { Login, Register } from './Buttons'

const logo = '../assets/images/logopce.png'

export default props => {

   return (
      <header className="header">
         <nav className="navbar navbar-expand-lg">
            <a className="navbar-brand" href="/">
               <Logo image={logo}>
               </Logo>
            </a>
            <ul className="navbar-nav">
               <li className="nav-item">
                  <a className="nav-link" href="/">
                     <span id="titulo">
                        <span>| PLATAFORMA DE CRESCIMENTO ESPIRITUAL</span>
                     </span>
                  </a>
               </li>
            </ul>
         </nav >
         <div className="d-flex align-items-center m-2">
            <Login></Login>
            <Register></Register>
         </div>
      </header >
   )
}

