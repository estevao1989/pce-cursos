import React, { useState, useContext } from "react"
import { useHistory } from "react-router"
import { useLocation } from 'react-router-dom'
import { VideoContext } from "../data/DataContext"
import axios from "axios"
import './Buttons.css'

export function Login() {

    const { playlistsTitle, setIsLoggedIn } = useContext(VideoContext)

    const history = useHistory()
    const [user, setUser] = useState("")
    const [pass, setPass] = useState("")

    function login (e){
        e.preventDefault()
        axios.get('http://localhost:3001/login', {
            params: {
                user: user,
                pass: pass
            }
        }).then(response =>{
            if(response.data[0].email && response.data[0].password){
                setIsLoggedIn(true)
                history.push('/')
            }   
        })
    }

    return (
        <div className="dropdown ">
            <button
                className="button button-red "
            >Login</button>
            <div class="dropdown-content p-3 container-sm">
                <form action="post">
                    <input onChange={(e) => setUser(e.target.value)} placeholder="Usuário" value={user}></input>
                    <input onChange={(e) => setPass(e.target.value)} type="password" placeholder="Senha" value={pass}></input>
                    <button onClick={(e) => login(e)}>Entrar</button>
                </form>
            </div>
        </div>
    )
}

export function Register() {

    const history = useHistory()
    let location = useLocation();

    return (
        <button
            className="button button-gray"
            onClick={() => history.push("/register")}
        >Registar</button>

    )
}
