import React, { useState } from 'react'
import { useHistory } from 'react-router'
import Main from './Main'
import axios from 'axios'
import './Register.css'

export default props => {

    const [nome, setNome] = useState("")
    const [contacto, setContacto] = useState("")
    const [email, setEmail] = useState("")
    const [pass, setPass] = useState("")

    function newRegister(e) {
        e.preventDefault()
        axios.post('http://localhost:3001/register', {
            nome: nome,
            contacto: contacto,
            email: email,
            pass: pass
        }).then(response =>{
            alert(response.data)
        })

    }

    const history = useHistory()
    return (
        <Main>
            <form className="formulario d-flex justify-content-center ">
                <div className="">
                    <label htmlFor="nome">Nome</label>
                    <input onChange={(e) => setNome(e.target.value)} type="text" className="form-control" id="nome" name="nome" value={nome} />
                </div>
                <div className="">
                    <label htmlFor="contacto">Contacto</label>
                    <input onChange={(e) => setContacto(e.target.value)} type="text" className="form-control" id="contacto" name="contacto" value={contacto} />
                </div>
                <div className="">
                    <label htmlFor="email">Email</label>
                    <input onChange={(e) => setEmail(e.target.value)} type="email" className="form-control" id="email" name="email" value={email} />
                </div>
                <div className="">
                    <label htmlFor="senha">Senha</label>
                    <input onChange={(e) => setPass(e.target.value)} type="password" className="form-control" id="senha" name="senha" value={pass} />
                </div>
                <button onClick={newRegister} type="submit" className="button button-gray">Registar</button>
            </form>
        </Main>
    )
}