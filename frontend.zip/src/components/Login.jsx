import React from 'react'
import Main from './Main'

export default props => {
    return(
        <Main>
            <div>Tela de Login</div>
        </Main>
    )
}