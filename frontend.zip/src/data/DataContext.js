import React, { useEffect, useState } from "react";
import axios from "axios";
import youtube from "../courses/youtube";

export const VideoContext = React.createContext();

export const DataProvider = (props) => {
  const [cursos, setCursos] = useState();
  const [playlistsTitle, setPlaylistsTitle] = useState([]);
  const [estado, setEstado] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  function getCursos() {
    axios.get("http://localhost:3001/cursos").then((response) => {
      setCursos(response.data);
    });
  }

  useEffect(() => {
    getCursos();
  }, []);

  useEffect(() => {
    buscarPlaylists(cursos);
  }, [cursos]);

  useEffect(() => {
    setEstado((estado) => !estado);
  }, [playlistsTitle]);

  function buscarPlaylists(cursos) {
    if (cursos !== undefined) {
      cursos.forEach((element) => {
        youtube
          .get("/playlists", {
            params: {
              id: element.curso,
              maxResults: 20,
            },
          })
          .then((response) => {
            setPlaylistsTitle((playlistsTitle) => [
              ...playlistsTitle,
              response.data.items[0],
            ]);
          });
      });
    }
  }

  return (
    <VideoContext.Provider
      value={{ cursos, playlistsTitle, estado, isLoggedIn ,setEstado, setIsLoggedIn }}
    >
      {props.children}
    </VideoContext.Provider>
  );
};
